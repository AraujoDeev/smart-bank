export const corPrimaria = "#41d3be";

export const fundoClaro = "#f1f1f1";
export const conteudoClaro = "white";
export const textoFundoClaro = "grey";

export const fundoEscuro = "#363537";
export const conteudoEscuro = "#5c5b5e";
export const textoFundoEscuro = "#fafafa";
