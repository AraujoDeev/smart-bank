export { default as cabecalho } from "./Cabecalho";
export { default as conta } from "./Conta";
export { default as container } from "./Container";
export { default as titulo } from "./Titulo";
