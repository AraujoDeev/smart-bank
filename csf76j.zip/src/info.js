export const extratoLista = {
  updates: [
    {
      id: "123131321",
      type: "Restaurante",
      value: "150,00",
      date: "11 JUN",
      from: "Bonna Parma"
    },
    {
      id: "4564654",
      type: "Utilidades",
      value: "130,00",
      date: "9 JUN",
      from: "CPFL *energia"
    },
    {
      id: "65445",
      type: "Saude",
      value: "15,00",
      date: "8 JUN",
      from: "Farma Ponte"
    },
    {
      id: "656565",
      type: "Transporte",
      value: "15,00",
      date: "8 JUN",
      from: "Uber"
    },

    {
      id: "926544",
      type: "Outros",
      value: "150,00",
      date: "5 JUN",
      from: "AliExpress"
    }
  ]
};
